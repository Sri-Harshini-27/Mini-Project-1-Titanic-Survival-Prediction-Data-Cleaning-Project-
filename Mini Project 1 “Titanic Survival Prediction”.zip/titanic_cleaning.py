"""
Mini Project 1: Titanic Survival Prediction - Data Cleaning
Tasks: clean missing data, encode Sex & Embarked, visualize Age, export cleaned CSV
"""
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid")

# ------------------------------------------------------------------
# 1. Load data
# ------------------------------------------------------------------
df = pd.read_csv("Titanic-Dataset.csv")
print("Shape:", df.shape)
print("\nMissing values BEFORE cleaning:\n", df.isna().sum()[lambda s: s > 0])

# Keep a copy of the original Age for the before/after comparison plot
age_before = df["Age"].copy()

# ------------------------------------------------------------------
# 2. Clean missing data
# ------------------------------------------------------------------
# Age (177 missing, ~20%): fill with the median Age of passengers who share
# the same Pclass and Sex. This is more accurate than one global median.
df["Age"] = df["Age"].fillna(
    df.groupby(["Pclass", "Sex"])["Age"].transform("median")
)

# Embarked (2 missing): fill with the most common port (mode)
df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])

# Cabin (687 missing, ~77%): too sparse to impute. Keep a simple
# "HasCabin" flag (cabin info often correlates with class/survival), then drop.
df["HasCabin"] = df["Cabin"].notna().astype(int)
df = df.drop(columns=["Cabin"])

# Drop identifier-like columns that carry no predictive signal
df = df.drop(columns=["PassengerId", "Name", "Ticket"])

# ------------------------------------------------------------------
# 3. Encode categorical columns
# ------------------------------------------------------------------
# Sex: binary label encoding (female = 0, male = 1)
df["Sex"] = df["Sex"].map({"female": 0, "male": 1})

# Embarked: one-hot encoding (no natural order between ports).
# drop_first=True removes the redundant column (Embarked_C is the baseline).
df = pd.get_dummies(df, columns=["Embarked"], prefix="Embarked", drop_first=True, dtype=int)

print("\nMissing values AFTER cleaning:", int(df.isna().sum().sum()))
print("\nCleaned columns:", list(df.columns))

# ------------------------------------------------------------------
# 4. Visualize Age distribution
# ------------------------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# (a) Before vs after imputation
sns.histplot(age_before.dropna(), bins=30, kde=True, color="steelblue", ax=axes[0])
axes[0].set_title("Age Distribution (original, 714 known values)")
sns.histplot(df["Age"], bins=30, kde=True, color="seagreen", ax=axes[1])
axes[1].set_title("Age Distribution (after cleaning, 891 values)")

# (b) Age by survival
sns.kdeplot(data=df, x="Age", hue="Survived", fill=True, common_norm=False,
            palette={0: "tomato", 1: "seagreen"}, ax=axes[2])
axes[2].set_title("Age Distribution by Survival (0 = No, 1 = Yes)")

for ax in axes:
    ax.set_xlabel("Age")
plt.tight_layout()
plt.savefig("age_distribution.png", dpi=150)
print("\nSaved plot: age_distribution.png")

# ------------------------------------------------------------------
# 5. Export cleaned dataset
# ------------------------------------------------------------------
df.to_csv("titanic_cleaned.csv", index=False)
print("Saved cleaned dataset: titanic_cleaned.csv", df.shape)
